<?php $__env->startSection('user-content'); ?>
<main class="main">
  

    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-12">
                <h2 class="mb-4">Historial de compras</h2>
                <div class="cart-table-container">
                    <table class="table table-cart">
                        <thead class="thead-dark">
                            <tr>
                                <th style="padding-top:12px !important" class="product-col">Producto</th>
                                <th style="padding-top:12px !important" class="qty-col">Cantidad</th>
                                <th style="padding-top:12px !important" class="price-col">Monto pagado</th>
                                <th style="padding-top:12px !important">Feahc de compra</th>
                                <th style="padding-top:12px !important">Estado</th>
                                <th style="padding-top:12px !important">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="product-row">
                                    <td class="product-col">
                                        <figure class="product-image-container" style="max-width: 100px !important;">
                                            <a href="product.html" class="product-image">
                                                <img src="<?php echo e(asset('poster/'.$item->poster)); ?>" alt="product">
                                            </a>
                                        </figure>
                                        <h2 class="product-title">
                                            <a href="product.html"><?php echo e($item->titulo); ?></a>
                                        </h2>
                                    </td>
                                    <td>
                                        <?php echo e($item->cantidad); ?> uni.
                                    </td>
                                    <td>$<?php echo e($item->total); ?></td>
                                    <td><?php echo e($item->createAt); ?></td>
                                    <td>
                                        <?php if($item->estado == 'Procesando'): ?>
                                            <span class="badge badge-primary" style="padding: 10px;">Procesando</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-danger btn-sm" style="min-width: 30px !important;"><i class="icon icon-cog"></i></button>
                                            <button type="button" class="btn btn-danger btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="min-width: 30px !important;">
                                              <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <div class="dropdown-menu">
                                              <a class="dropdown-item" href="#"><i class="icon icon-truck"></i> Detalles de envio</a>
                                              <a class="dropdown-item" href="#"><i class="icon icon-minus-squared"></i> Cancelar compra</a>
                                              <a class="dropdown-item" href="#">Something else here</a>
                                              <div class="dropdown-divider"></div>
                                              <a class="dropdown-item" href="#">Separated link</a>
                                            </div>
                                          </div>
                                    </td>
                                </tr> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        
                    </table>
                    <hr>
                    <?php echo e($ventas->render()); ?>

                </div><!-- End .cart-table-container -->

                
            </div><!-- End .col-lg-8 -->

            
        </div><!-- End .row -->
    </div><!-- End .container -->

    <div class="mb-6"></div><!-- margin -->
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/mis_compras.blade.php ENDPATH**/ ?>