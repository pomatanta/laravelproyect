<?php $__env->startSection('user-content'); ?>
<main class="main">
    <div class="container mt-4">
       

        <div class="product-wrapper"><div class="product-intro divide-line up-effect">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-3 product-default">
                    <figure>
                        <a href="<?php echo e(route('producto',$item->slug)); ?>">
                            <img src="<?php echo e(asset('poster/'.$item->poster)); ?>">
                        </a>
                        <!-- <span class="product-label label-sale">27% OFF</span> -->
                    </figure>
                    <div class="product-details">
                        <div class="category-list">
                            <a href="<?php echo e(route('productos.categoria',$item->categoria)); ?>" class="product-category"><?php echo e($item->categoria); ?></a>
                        </div>
                        <h2 class="product-title" style="text-align: center;">
                            <a href="<?php echo e(route('producto',$item->slug)); ?>" style="white-space: normal;"><?php echo e($item->titulo); ?></a>
                        </h2>
                        <div class="ratings-container">
                            <div class="product-ratings">
                                <span class="ratings" style="width:0%"></span><!-- End .ratings -->
                                <span class="tooltiptext tooltip-top"></span>
                            </div><!-- End .product-ratings -->
                        </div><!-- End .product-container -->
                        <div class="price-box">
                            <span class="product-price">$<?php echo e($item->precio_ahora); ?></span>
                            <del><?php echo e($item->precio_antes); ?></del>
                        </div><!-- End .price-box -->
                        <div class="product-action">
                            <a href="#" class="btn-icon-wish"><i class="icon-heart"></i></a>
                                            
                            <form action="<?php echo e(route('agregar.carrito')); ?>" method="POST" style="margin:0 !important">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="cantidad" value="1">
                                <input type="hidden" value="<?php echo e($item->id); ?>" name="idproducto">
                                <button class="btn-icon btn-add-cart"  type="submit"><i class="icon-bag"></i>AL CARRITO</button>
                            </form>
                        </div>
                    </div><!-- End .product-details -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <nav class="toolbox toolbox-pagination">
            <div class="toolbox-item toolbox-show">
                <label>Productos mas vendidos</label>
            </div><!-- End .toolbox-item -->

          
        </nav>
    </div><!-- End .container -->

    <div class="mb-5"></div><!-- margin -->
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/best-seller.blade.php ENDPATH**/ ?>