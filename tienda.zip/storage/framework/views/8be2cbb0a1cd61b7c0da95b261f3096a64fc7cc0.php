<?php $__env->startSection('admin'); ?>
<div class="main mb-4">
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="content">
        <div class="container-fluid">

            <div class="header">
                <h1 class="header-title">
                    <i class="fas fa-shopping-basket"></i> Detalles de la venta
                </h1>
                <p class="header-subtitle">Información detallada de la venta: .</p>
            </div>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-info alert-outline alert-dismissible" role="alert">
                    <div class="alert-icon">
                        <i class="far fa-fw fa-bell"></i>
                    </div>
                    <div class="alert-message">
                        <?php echo e(Session::get('success')); ?>

                    </div>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger alert-outline alert-dismissible" role="alert">
                    <div class="alert-icon">
                        <i class="far fa-fw fa-bell"></i>
                    </div>
                    <div class="alert-message">
                        <?php echo e(Session::get('danger')); ?>

                    </div>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-lg-7 col-md-12">
                   <div class="card">
                       <div class="card-header">
                           <h5>Detalles del producto</h5>
                       </div>
                       <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4" style="border-right: 1px solid #bcb8b8;padding-right:18px">
                                    <img src="<?php echo e(asset('poster/'.$venta->poster)); ?>" style="width:100%">
                                </div>
                                <div class="col-lg-8">
                                    <h5><?php echo e($venta->titulo); ?></h5>
                                    <p style="margin-bottom:0px"><b>Categoría: </b><?php echo e($venta->categoria); ?></p>
                                    <p style="margin-bottom:0px"><b>Monto pagado: </b>USD <?php echo e($venta->total); ?></p>
                                    <p style="margin-bottom:0px"><b>Cantidad: </b>x <?php echo e($venta->cantidad); ?></p>
                                    <p style="margin-bottom:0px"><b>Código venta: </b> <?php echo e(strtoupper($venta->codigo)); ?></p>
                                    <p style="margin-bottom:0px"><b>Transacción: </b> <?php echo e($venta->transaccion); ?></p>
                                    <p style="margin-bottom:0px"><b>Método de págo: </b> <?php echo e($venta->metodo); ?></p>
                                    <p style="margin-bottom:0px"><b>Fecha facturación: </b> <?php echo e($venta->fecha); ?></p>
                                </div>
                            </div>
                       </div>
                   </div>
                </div>
                <div class="col-lg-5 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Dirección de envio</h5>
                        </div>
                        <div class="card-body">
                            <h5>Dirección de envio principal</h5>
                            <?php echo $venta->direccion?><br>
                            <p style="margin-bottom: 0px;"><b>País: </b> <?php echo e($venta->pais); ?></p>
                            <p style="margin-bottom: 0px;"><b>Región: </b> <?php echo e($venta->region); ?></p>
                            <p style="margin-bottom: 0px;"><b>Ciudad: </b> <?php echo e($venta->ciudad); ?></p>
                            <p style="margin-bottom: 45px;"><b>ZIP: </b> <?php echo e($venta->zip); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-7">
                   <div class="card">
                       <div class="card-header">
                           <h5>Datos de envio</h5>
                       </div>
                       <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4" style="border-right: 1px solid #bcb8b8;padding-right:18px">
                                    <center><img src="<?php echo e(asset('img/direccion.png')); ?>" style="width:80%"></center>
                                </div>
                                <div class="col-lg-8">
                                    
                                    <p style="margin-bottom:0px"><b>Propietario: </b><?php echo e($venta->name); ?> <?php echo e($venta->fullname); ?></p>
                                    <p style="margin-bottom:0px"><b>Correo Electrónico: </b><?php echo e($venta->email); ?></p>
                                    <p style="margin-bottom:0px"><b>Seguimiento: </b>
                                        <?php if($venta->estado == 'Cancelado' || $venta->estado == 'Reembolsado'): ?>
                                            &nbsp; <span class="badge badge-danger">Cancelado</span>
                                        <?php else: ?>
                                            <?php if($venta->track): ?>
                                                &nbsp; <span class="badge badge-primary"><?php echo e($venta->track); ?></span>
                                            <?php else: ?>
                                                &nbsp; <span class="badge badge-primary">Procesando</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </p>
                                    <p style="margin-bottom:0px"><b>Tiempo estimado: </b>
                                        <?php if($venta->estado == 'Cancelado' || $venta->estado == 'Reembolsado'): ?>
                                            &nbsp; <span class="badge badge-danger">Cancelado</span>
                                        <?php else: ?>
                                            <?php if($venta->tiempo): ?>
                                            &nbsp; <span class="badge badge-secondary"><?php echo e($venta->tiempo); ?></span>
                                            <?php else: ?>
                                            &nbsp; <span class="badge badge-secondary">Procesando</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </p>
                                    <p style="margin-bottom:0px"><b>Estado del pedido: </b>
                                        <?php if($venta->estado): ?>
                                        &nbsp; <span class="badge badge-info"><?php echo e($venta->estado); ?></span>
                                        <?php else: ?>
                                        &nbsp; <span class="badge badge-info"><?php echo e($venta->estado); ?></span>
                                        <?php endif; ?>
                                    </p>
                                    <p style="margin-bottom:0px"><b>Médio postal: </b>
                                        <?php if($venta->medio_postal): ?>
                                            &nbsp; <span class="badge badge-info"><?php echo e($venta->medio_postal); ?></span>
                                        <?php else: ?>
                                            &nbsp; <span class="badge badge-warning">Procesando</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                       </div>
                   </div>
                </div>
            </div>
            

        </div>
    </main>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/admin/ventas/detalle.blade.php ENDPATH**/ ?>