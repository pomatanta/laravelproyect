<?php $__env->startSection('admin'); ?>
<div class="main">
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="content">
        <div class="container-fluid">
           
                <div class="header">
                    <h1 class="header-title">
                        Apartado de productos
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index.producto')); ?>">Productos</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Editar registro</li>
                        </ol>
                    </nav>
                </div>
            
                <div class="row">
                    <?php if(Session::has('danger')): ?>
                        <div class="col-lg-12 form-group">
                            <div class="alert alert-danger alert-outline alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <i class="far fa-fw fa-bell"></i>
                                </div>
                                <div class="alert-message">
                                <?php echo e(Session::get('danger')); ?>

                                </div>
            
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-lg-12">
                        <form method="POST" action="<?php echo e(route('update.producto',$producto->slug)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="PATCH">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row mt-4">
                                        <div class="col-lg-8">
                                            <div class="row">
                                                <div class="col-lg-9 form-group">
                                                    <label><b>Titulo del producto</b></label>
                                                    <input type="text" name="titulo" class="form-control <?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>"  value="<?php echo e($producto->titulo); ?>">
                                                    <?php if($errors->has('titulo')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('titulo')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3 form-group">
                                                    <label><b>Categoría</b></label>
                                                    <select name="idcategoria" class="form-control <?php echo e($errors->has('idcategoria') ? ' is-invalid' : ''); ?>" >
                                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($producto->idcategoria == $item->id): ?>
                                                                <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->titulo); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->titulo); ?></option>
                                                            <?php endif; ?>   
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('idcategoria')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('idcategoria')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3 form-group">
                                                    <label><b>Stock</b></label>
                                                    <input type="number" name="stock" class="form-control <?php echo e($errors->has('stock') ? ' is-invalid' : ''); ?>"  value="<?php echo e($producto->stock); ?>">
                                                    <?php if($errors->has('stock')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('stock')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3 form-group">
                                                    <label><b>Precio antes</b></label>
                                                    <input type="number" name="precio_antes" class="form-control <?php echo e($errors->has('precio_antes') ? ' is-invalid' : ''); ?>" value="<?php echo e($producto->precio_antes); ?>">
                                                    <?php if($errors->has('precio_antes')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('precio_antes')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3 form-group">
                                                    <label><b>Precio ahora</b></label>
                                                    <input type="number" name="precio_ahora" class="form-control <?php echo e($errors->has('precio_ahora') ? ' is-invalid' : ''); ?>" value="<?php echo e($producto->precio_ahora); ?>">
                                                    <?php if($errors->has('precio_ahora')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('precio_ahora')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3 form-group">
                                                    <label><b>Estado</b></label>
                                                    <input type="text" readonly value="ACTIVO" class="form-control">
                                                </div>
                                                <div class="col-lg-12 form-group">
                                                    <textarea name="reseña" class="form-control <?php echo e($errors->has('reseña') ? ' is-invalid' : ''); ?>" style="height:80px !important"><?php echo e($producto->reseña); ?></textarea>
                                                    <?php if($errors->has('reseña')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('reseña')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <div class="col-lg-12 form-group">
                                                    <textarea name="contenido" id="editor" class="<?php echo e($errors->has('contenido') ? ' is-invalid' : ''); ?>"><?php echo e($producto->contenido); ?></textarea>
                                                    <?php if($errors->has('contenido')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('contenido')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                

                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <div class="col-lg-12 form-group">
                                                    <div class="text-center">
                                                        <label><b>Portada</b></label>
                                                        <br>
                                                        <img src="<?php echo e(asset('poster/'.$producto->poster)); ?>" class=" img-responsive mt-2" id="blah" width="150" height="190">
                                                        <div class="mt-2">
                                                            <input id="imgInp" class="btn btn-primary" type="file" name="poster" >
                                                        </div>
                                                        <small>For best results, use an image at least 128px by 128px in .jpg
                                                        format</small>
                                                        <?php if($errors->has('poster')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('poster')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 text-center">
                                                    <button class="btn btn-primary btn-lg" type="submit"><i class="fas fa-save"></i> Actualizar</button>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            
        </div>
    </main>
    
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
        
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                $('#blah').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#imgInp").change(function() {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/admin/producto/edit.blade.php ENDPATH**/ ?>