<?php $__env->startSection('user-content'); ?>
<main class="main">
    <div class="container">
        <div class="row" style="margin-top: 50px; margin-bottom: 50px">
            <?php if(Session::has('success')): ?>
                <div class="col-md-12 form-group">
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-6">
                <h2 class="title mb-2">Iniciar Sesión</h2>
        
                <form method="POST" action="<?php echo e(route('login')); ?>" class="mb-1" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <label for="login-email">Correo Electróninco <span class="required">*</span></label>
                    <input type="email" class="form-input form-wide mb-2" id="login-email" required autocomplete="new-text" name="email">
                        
        
                    <label for="login-password">Contrasena <span class="required">*</span></label>
                    <input type="password" class="form-input form-wide mb-2" id="login-password" required autocomplete="new-password" name="password">

                    <?php if($errors->has('email')): ?>
                        <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('email')); ?></span><br>
                    <?php endif; ?>
                    
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-md">LOGIN</button>
        
                        
                    </div><!-- End .form-footer -->
                    <a href="#" class="forget-password"> Olvidó su contrasena?</a>
                </form>
            </div><!-- End .col-md-6 -->
        
            <div class="col-md-6">
                <h2 class="title mb-2">Registro rápido</h2>
        
                <form action="<?php echo e(route('registro.rapido')); ?>" method="POST" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <label for="register-email">Correo Electróninco <span class="required">*</span></label>
                    <input type="email" class="form-input form-wide mb-2" id="register-email" required autocomplete="new-text" name="email">

                        <?php if($errors->has('email')): ?>
                            <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
        
                    <label for="register-password">Contrasena <span class="required">*</span></label>
                    <input type="password" class="form-input form-wide mb-2" id="register-password" required autocomplete="new-password" name="password">

                        <?php if($errors->has('password')): ?>
                            <span class="help-block" style="color: #ff0000"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
        
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-md">Registrar</button>
        
                    </div><!-- End .form-footer -->
                </form>
            </div><!-- End .col-md-6 -->
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tienda\resources\views/auth/loginuser.blade.php ENDPATH**/ ?>